package it.gabbo.io;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.SwingConstants;


public class Lampadina {
	private JFrame frame;
	public ImageIcon light_bulb;
	public  JLabel Label;
	boolean btnOff = true;
	boolean isOn = true;
	int maxClicks = 25;
	JButton btn = new JButton("OFF");
	private JLabel statusLabel;
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Lampadina window = new Lampadina();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public Lampadina() {
		initialize();
	}
	
	public void click(String status) {
		if (status != "Rotta") {
			if (btnOff == true) {
				btn.setText("ON");
				Label.setIcon(new ImageIcon(this.getClass().getResource("/light_bulb_off.jpg")));
				btn.setBackground(Color.GREEN);
				btnOff = false;
			} else if (btnOff == false) {
				btn.setText("OFF");
				Label.setIcon(new ImageIcon(this.getClass().getResource("/light_bulb_on.jpg")));
				btn.setBackground(Color.RED);
				btnOff = true;
			}
		} else {
			Label.setIcon(new ImageIcon(this.getClass().getResource("/light_bulb_broken.jpg")));
		}
	}
	
	public String stato() {
		String status = null;
		if (maxClicks >= 1) {
			maxClicks -= 1;
			if (isOn == true) {
				status = "Accesa";
				isOn = false;
			} else if (isOn == false) {
				status = "Spenta";
				isOn = true;
			}
		} else {
			btn.setEnabled(false);
			status = "Rotta";
		}
		
		return status;
	}

	private void initialize() {
		light_bulb = new ImageIcon(this.getClass().getResource("/light_bulb_on.jpg"));
		Label = new JLabel(light_bulb);
		Label.setLocation(0, 0);
		Label.setSize(529, 467);
		
		btn.setBackground(Color.RED);
		
		statusLabel = new JLabel("");
		statusLabel.setHorizontalAlignment(SwingConstants.CENTER);
		statusLabel.setBounds(580, 48, 60, 22);
		statusLabel.setForeground(Color.YELLOW);
		
		btn.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String status = stato();
				System.out.println(status);
				click(status);
				statusLabel.setText(status);
			}
		});
		
		btn.setForeground(Color.WHITE);
		btn.setBounds(580, 180, 60, 89);
		
		frame = new JFrame();
		frame.setResizable(false);
		frame.getContentPane().setBackground(Color.BLACK);
		frame.setBounds(100, 100, 809, 506);
		frame.getContentPane().add(Label);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.getContentPane().add(btn);
		frame.getContentPane().add(statusLabel);
	}
}