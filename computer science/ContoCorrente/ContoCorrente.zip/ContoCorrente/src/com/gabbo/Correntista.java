package com.gabbo;
import javax.xml.crypto.dsig.spec.XSLTTransformParameterSpec;
import java.util.ArrayList;
import java.util.Scanner;

public class Correntista {
    ArrayList<String> nameSaved = new  ArrayList<String>();
    ArrayList<String> lastnameSaved = new  ArrayList<String>();
    String nome, cognome;
    int i = 0;
    String pin;
    ArrayList<String> savedPins = new  ArrayList<String>();
    boolean check = false;
    Scanner kb = new Scanner(System.in);

    public void saldo() {
        String choice;
        float importo = 0;
        float saldo = 0;
        float max = 3000;
        System.out.println("""
        [0] Prelievo
        [1] Versamento
        [2] Visualizza saldo
        [3] Esci
                """);
        choice = kb.next();

        switch (choice) {
            case "0":
                System.out.println("Importo da prelevare:");
                importo = kb.nextFloat();
                if (saldo >= 0) {
                    saldo -= importo;
                    max -= saldo;
                    System.out.println(saldo);
                } else if (importo > max) {
                    System.out.println("Hai raggiunto il massimo fido prelevabile");
                } else {
                    saldo -= importo;
                    max -= saldo;
                    System.out.println(saldo);
                }
                break;
            case "1":
                System.out.println("Inserisci l'importo:");
                saldo = kb.nextFloat();
                System.out.println("Versati €" + saldo);
                break;
            case "2":
                System.out.println(saldo + "€");
                break;
            case "3":
                break;
            default:
                System.out.println("Scelta errata");
                break;
        }
    }

    public void register() {
        i += 1;
        System.out.println("Nome:");
        nome = kb.next();
        System.out.println("Cognome:");
        cognome = kb.next();
        System.out.println("Digita un pin");
        pin = kb.next();

        for (int j = 0; j < savedPins.size(); j++) {
            if (savedPins.get(j).equals(pin)) {
                System.out.println("Pin esistente");
                check = true;
                break;
            } else {
                continue;
            }
        }

        if (check == true) {
            System.exit(0);

        } else {
            System.out.println("Registrazione effettuata");
            savedPins.add(pin);
            nameSaved.add(nome);
            lastnameSaved.add(cognome);
            pin = "";
            /* for (int j = 0; j < savedPins.size(); j++) {
                System.out.println(nameSaved.get(j) + " " + lastnameSaved.get(j) + " " + savedPins.get(j));
            } */

        }
    }

    public void login() {
        System.out.println("Nome:");
        nome = kb.next();
        System.out.println("Cognome:");
        cognome = kb.next();
        System.out.println("Pin:");
        pin = kb.next();

        for (int j = 0; j < savedPins.size(); j++) {
            if (nome.equals(nameSaved.get(j)) && cognome.equals(lastnameSaved.get(j)) && pin.equals(savedPins.get(j))) {
                System.out.println("Login effettuato");
                saldo();
                check = false;
                break;
            } else {
                continue;
            }
        }
    }
}
